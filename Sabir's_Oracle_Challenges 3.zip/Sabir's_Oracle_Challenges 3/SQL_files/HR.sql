-- To see the tables you have in HR 

select table_name from user_tables 
select * from employees
select * from departments
select * from countries
select * from locations
select * from jobs
select * from job_history
select * from regions

----====================starting the test ====================

-- My question A1 
select * from employees














--MY A1 answer

SELECT employee_id , first_name ,last_name, 
job_id, department_id , salary
FROM employees 
WHERE salary > 11000 
ORDER BY salary DESC;

-- A2 
SELECT employee_id, last_name,
manager_id, department_id
FROM employees
WHERE manager_id IS NULL 
or department_id = 70;

--A3
SELECT employee_id,
first_name || ' ' || last_name as fullname,
salary, department_id 
FROM employees
ORDER BY salary DESC
FETCH FIRST 7 ROWS ONLY;

--A4
SELECT employee_id, last_name ,
department_id 
FROM employees
WHERE department_id IN (50,60,80);

--A5
SELECT employee_id, last_name,
'Job id : ' || job_id AS  "Employee Details"
FROM employees;


--C1

SELECT last_name, salary ,
MOD(salary,500) AS remind 
from employees 

--C2 
SELECT last_name, hire_date,
TRUNC((SYSDATE - hire_date) / 7) AS  employed_weeks
FROM employees;

-- C3
SELECT AVG(commission_pct) AS avg_lefting_nulls,
AVG(NVL(commission_pct, 0)) AS avg_nulls_as_zero
FROM employees;

-- C4
SELECT job_id, COUNT(*) AS total_employees, 
SUM(salary) AS total_payroll
FROM employees
GROUP BY job_id
ORDER BY SUM(salary) DESC;

--C5
SELECT department_id, MAX(salary) AS max_slry
FROM employees
GROUP BY department_id
HAVING MAX(salary) > 12800
ORDER BY MAX(salary) DESC;




