SHOW CON_NAME;
SELECT username FROM all_users WHERE username IN ('HR');

SHOW CON_NAME;


-- create user 

--PART B  creating  labuser45 and allow to login
CREATE USER LAB_USER_45 IDENTIFIED BY U45
GRANT CREATE SESSION TO LAB_USER_45;

SELECT username FROM all_users
WHERE username = 'LAB_USER_45';

--create role to lab_user-45

CREATE ROLE LAB_READ_45;

-- allow lab_user_45 to read data from HR.employees and to lab user

GRANT SELECT ON hr.employees TO LAB_READ_45;
GRANT LAB_READ_45 TO LAB_USER_45;



-- Granting lab_user_45
REVOKE LAB_READ_45 FROM LAB_USER_45;
















