
--checking if user exist
SELECT USER FROM dual;

-- check if there is usr_privilage 
SELECT * FROM user_role_privs;
-- selecting hr employee if exist here
SELECT * FROM hr.employees;




