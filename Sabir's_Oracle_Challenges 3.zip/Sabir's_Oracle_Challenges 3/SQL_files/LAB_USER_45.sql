-- in LAB_USER_45 CHECK SELECT
SELECT * FROM HR.employees


-- CHECK UPDATE IF WORKS

UPDATE HR.employees 
SET salary = 10000
WHERE employee_id = 100


